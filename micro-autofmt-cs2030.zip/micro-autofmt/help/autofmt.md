# micro-autofmt

- Run `fmt` to format the current file.
- Files will be formatted on save, unless `fmt-onsave` is set to false.
